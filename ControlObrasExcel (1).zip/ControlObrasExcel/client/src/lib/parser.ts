import { Activity, CategoryGroup } from "../types";

export const parseActivities = (text: string): CategoryGroup[] => {
  const lines = text.split('\n').map(l => l.trim()).filter(Boolean);
  
  const categoryPatterns = [
    { name: "1. Obras previas / Terreno", pattern: /^1\.\s*Obras/ },
    { name: "2. Cimentaciones y zapatas", pattern: /^2️⃣\s*Cimentaciones/ },
    { name: "3. Columnas y muros (Primer nivel)", pattern: /^3️⃣\s*Columnas/ },
    { name: "4. Muros de bloque", pattern: /^4️⃣\s*Muros/ },
    { name: "5. Losas y entrepisos", pattern: /^5️⃣\s*Losas/ },
    { name: "6. Cubierta / Techo", pattern: /^6️⃣\s*Cubierta/ },
    { name: "7. Instalaciones hidrosanitarias", pattern: /^7️⃣\s*Instalaciones/ },
    { name: "8. Acabado de muros y cajillos", pattern: /^8️⃣\s*Acabado/ },
    { name: "9. Paredes de tablayeso", pattern: /^9️⃣\s*Paredes/ },
    { name: "10. Instalaciones eléctricas", pattern: /^🔟\s*Instalaciones/ },
    { name: "11. Carpintería y marcos", pattern: /^1️⃣1️⃣\s*Carpintería/ },
    { name: "12. Aparatos sanitarios y equipos", pattern: /^1️⃣2️⃣\s*Aparatos/ },
    { name: "13. Obras exteriores y paisajismo", pattern: /^1️⃣3️⃣\s*Obras/ },
    { name: "14. Construcción de cisterna", pattern: /^14️⃣\s*Construcción/ },
    { name: "15. Limpieza final y entrega", pattern: /^1️⃣\s*5️⃣\s*Limpieza/ },
  ];

  const groups: CategoryGroup[] = categoryPatterns.map(c => ({
    name: c.name,
    activities: [],
    totalProgress: 0
  }));

  let currentCategoryIndex = -1;
  let currentBlock: { id?: number, lines: string[] } | null = null;

  const flushBlock = () => {
    if (!currentBlock || !currentBlock.id || currentCategoryIndex === -1) return;
    
    const contentLines = currentBlock.lines;
    const nameParts: string[] = [];
    let foundEnd = false;
    
    for (const line of contentLines) {
      if (line.includes('%') || line === 'FALSO' || line === 'VERDADERO' || line.includes("00:00")) {
        foundEnd = true;
        continue;
      }
      if (foundEnd) continue;
      
      // More aggressive filtering of category names
      // We'll remove any words that appear in the current category title to avoid "Losas y entrepisos Colado..."
      const currentCatName = groups[currentCategoryIndex].name;
      // Create a regex from the category name words (excluding numbers/bullets)
      const catWords = currentCatName.replace(/^\d+[.|️⃣]*\s*/, '').split(/[\s/]+/);
      
      let isArtifact = false;
      for (const word of catWords) {
          if (word.length > 3 && line.includes(word)) {
              // Check if the line is JUST the category name (or very close)
              // If line is "Losas y entrepisos", skip it.
              // If line is "Colado de losas", keep it.
              if (line.length <= word.length + 5 || line === currentCatName) {
                  isArtifact = true; 
                  break;
              }
          }
      }
      
      const specificArtifacts = ["Obras", "previas", "Cimentaciones", "Columnas", "Muros", "Losas", "Cubierta", "Instalaciones", "Acabado", "Paredes", "Carpintería", "Aparatos", "Construcción", "Limpieza", "Cisternas", "sub-actividades", "sub-actividad", "De muros y cajillos"];
      if (specificArtifacts.includes(line)) isArtifact = true;

      if (!isArtifact && line.length > 1) { 
         nameParts.push(line);
      }
    }
    
    let activityName = nameParts.join(' ');
    
    // Explicit cleanup of known repetitions based on the provided text structure
    const currentCatClean = groups[currentCategoryIndex].name.replace(/^\d+[.|️⃣]*\s*/, '');
    if (activityName.startsWith(currentCatClean)) {
        activityName = activityName.substring(currentCatClean.length).trim();
    }
    
    // Remove known prefixes for specific categories
    const prefixesToRemove: Record<string, string[]> = {
        'Acabado': ['De muros y cajillos', 'de muros y cajillos'],
    };
    
    for (const [catKeyword, prefixes] of Object.entries(prefixesToRemove)) {
        if (currentCatClean.includes(catKeyword)) {
            for (const prefix of prefixes) {
                const regex = new RegExp(`^${prefix}\\s+`, 'i');
                activityName = activityName.replace(regex, '');
            }
        }
    }
    
    activityName = activityName.replace(/^y\s+/, '');
    activityName = activityName.replace(/^\W+/, '');
    
    if (!activityName) activityName = "Actividad " + currentBlock.id;
    
    activityName = activityName.charAt(0).toUpperCase() + activityName.slice(1);

    groups[currentCategoryIndex].activities.push({
      id: currentBlock.id,
      category: groups[currentCategoryIndex].name,
      name: activityName,
      notes: '',
      status: 'pending',
      progress: 0,
      urgent: false
    });
  };

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    
    const categoryMatchIndex = categoryPatterns.findIndex(p => p.pattern.test(line));
    if (categoryMatchIndex !== -1) {
      if (currentBlock) flushBlock();
      currentBlock = null;
      currentCategoryIndex = categoryMatchIndex;
      continue;
    }

    if (/^\d+$/.test(line)) {
      if (currentBlock) flushBlock();
      currentBlock = { id: parseInt(line), lines: [] };
      continue;
    }

    if (currentBlock) {
      currentBlock.lines.push(line);
    }
  }
  
  if (currentBlock) flushBlock();

  // Apply custom names for category #8 (Acabado de muros y cajillos)
  const acabadoCategory = groups.find(g => g.name.includes('Acabado de muros y cajillos'));
  if (acabadoCategory) {
    const customNames: Record<number, string> = {
      63: 'Pulido de paredes',
      64: 'Curado de pulidos',
      65: 'Cubrimiento de cajillos con tablayeso',
      66: 'Colocación de estructura de tablayeso y canaleta galvanizada',
      67: 'Enmasillado de juntas y superficies',
      68: 'Pulido y lijado final',
      69: 'Pintura'
    };
    
    acabadoCategory.activities = acabadoCategory.activities.map(act => {
      if (customNames[act.id]) {
        return { ...act, name: customNames[act.id] };
      }
      return act;
    });
  }

  return groups.filter(g => g.activities.length > 0 || true);
};
