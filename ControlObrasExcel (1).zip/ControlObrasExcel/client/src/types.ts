export interface Activity {
  id: number;
  category: string;
  name: string;
  notes: string;
  status: 'pending' | 'completed' | 'stopped';
  progress: 0 | 25 | 50 | 75 | 100;
  completedAt?: string; // ISO date string
  lastUpdated?: string; // ISO date string
  urgent?: boolean; // Priority marking
}

export interface CategoryGroup {
  name: string;
  activities: Activity[];
  totalProgress: number;
}

export interface Project {
  id: string;
  name: string;
  code: string;
  createdAt: string;
  data: CategoryGroup[];
  issues: Issue[];
}

export interface Issue {
  id: string;
  description: string;
  solution: string;
  severity: 25 | 50 | 75 | 100;
  date: string;
  category?: string; // Optional link to a category
}

export type FilterType = 'all' | 'pending' | 'completed' | 'stopped';
