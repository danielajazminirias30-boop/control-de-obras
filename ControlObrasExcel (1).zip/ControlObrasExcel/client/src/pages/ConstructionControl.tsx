import React, { useState, useEffect, useMemo, useRef } from 'react';
import { 
  CheckCircle2, 
  Clock, 
  AlertTriangle, 
  BarChart3, 
  List, 
  Search, 
  Filter, 
  Calendar, 
  ChevronDown, 
  ChevronRight,
  Plus,
  Minus,
  Trash2,
  MoreHorizontal,
  Download,
  FolderPlus,
  FolderOpen,
  AlertOctagon,
  Zap,
  ZapOff
} from 'lucide-react';
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle 
} from '@/components/ui/card';
import { 
  Tabs, 
  TabsContent, 
  TabsList, 
  TabsTrigger 
} from '@/components/ui/tabs';
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from '@/components/ui/select';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '@/components/ui/table';
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { ScrollArea } from '@/components/ui/scroll-area';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  Cell,
  PieChart,
  Pie
} from 'recharts';
import { parseActivities } from '@/lib/parser';
import { Activity, CategoryGroup, Project, Issue } from '@/types';
import { format, startOfWeek, endOfWeek, isWithinInterval, parseISO } from 'date-fns';
import { es } from 'date-fns/locale';
import * as htmlToImage from 'html-to-image';

const DEFAULT_PROJECT_ID = 'default-001';

export default function ConstructionControl() {
  const [projects, setProjects] = useState<Project[]>([]);
  const [currentProjectId, setCurrentProjectId] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [expandedCategories, setExpandedCategories] = useState<Record<string, boolean>>({});
  
  // New Project State
  const [newProjectOpen, setNewProjectOpen] = useState(false);
  const [newProjectData, setNewProjectData] = useState({ name: '', code: '' });

  // New Activity State
  const [newActivityOpen, setNewActivityOpen] = useState(false);
  const [newActivityData, setNewActivityData] = useState({ category: '', name: '' });

  // Issue Tracker State
  const [newIssueOpen, setNewIssueOpen] = useState(false);
  const [newIssueData, setNewIssueData] = useState<Partial<Issue>>({ severity: 50 });
  
  const weeklySummaryRef = useRef<HTMLDivElement>(null);

  const currentProject = useMemo(() => 
    projects.find(p => p.id === currentProjectId), 
  [projects, currentProjectId]);

  useEffect(() => {
    const initData = async () => {
      // Try load from localStorage first
      const savedProjects = localStorage.getItem('construction-projects');
      
      if (savedProjects) {
        try {
          let parsed = JSON.parse(savedProjects);
          
          // Migrate/fix activity names for category #8 (Acabado de muros y cajillos)
          const customNames: Record<number, string> = {
            63: 'Pulido de paredes',
            64: 'Curado de pulidos',
            65: 'Cubrimiento de cajillos con tablayeso',
            66: 'Colocación de estructura de tablayeso y canaleta galvanizada',
            67: 'Enmasillado de juntas y superficies',
            68: 'Pulido y lijado final',
            69: 'Pintura'
          };
          
          parsed = parsed.map((proj: Project) => ({
            ...proj,
            data: proj.data.map((cat: CategoryGroup) => {
              if (cat.name.includes('Acabado de muros y cajillos')) {
                return {
                  ...cat,
                  activities: cat.activities.map((act: Activity) => {
                    if (customNames[act.id]) {
                      return { ...act, name: customNames[act.id] };
                    }
                    return act;
                  })
                };
              }
              return cat;
            })
          }));
          
          if (parsed.length > 0) {
            setProjects(parsed);
            setCurrentProjectId(parsed[0].id);
            setLoading(false);
            // Restore expanded state
             const initialExpanded: Record<string, boolean> = {};
             parsed[0].data.forEach((c: CategoryGroup) => initialExpanded[c.name] = true);
             setExpandedCategories(initialExpanded);
            return;
          }
        } catch (e) {
          console.error("Error parsing saved projects", e);
        }
      }

      // If no saved data, load default
      try {
        const response = await fetch('/data.txt');
        const text = await response.text();
        const parsedData = parseActivities(text);
        
        const defaultProject: Project = {
          id: DEFAULT_PROJECT_ID,
          name: 'Proyecto Demo',
          code: 'DEMO-01',
          createdAt: new Date().toISOString(),
          data: parsedData,
          issues: []
        };

        setProjects([defaultProject]);
        setCurrentProjectId(DEFAULT_PROJECT_ID);
        
        const initialExpanded: Record<string, boolean> = {};
        parsedData.forEach(c => initialExpanded[c.name] = true);
        setExpandedCategories(initialExpanded);
      } catch (error) {
        console.error("Failed to load initial data", error);
      } finally {
        setLoading(false);
      }
    };
    initData();
  }, []);

  // Persist changes
  useEffect(() => {
    if (projects.length > 0) {
      localStorage.setItem('construction-projects', JSON.stringify(projects));
    }
  }, [projects]);

  const createProject = async () => {
    if (!newProjectData.name || !newProjectData.code) return;

    // Load fresh template data
    try {
      const response = await fetch('/data.txt');
      const text = await response.text();
      const parsedData = parseActivities(text);

      const newProject: Project = {
        id: crypto.randomUUID(),
        name: newProjectData.name,
        code: newProjectData.code,
        createdAt: new Date().toISOString(),
        data: parsedData,
        issues: []
      };

      setProjects(prev => [...prev, newProject]);
      setCurrentProjectId(newProject.id);
      setNewProjectOpen(false);
      setNewProjectData({ name: '', code: '' });
    } catch (e) {
      console.error("Error creating project template", e);
    }
  };

  const toggleCategory = (categoryName: string) => {
    setExpandedCategories(prev => ({
      ...prev,
      [categoryName]: !prev[categoryName]
    }));
  };

  const updateActivity = (categoryId: string, activityId: number, updates: Partial<Activity>) => {
    if (!currentProjectId) return;

    setProjects(prev => prev.map(proj => {
      if (proj.id !== currentProjectId) return proj;

      const updatedCategories = proj.data.map(cat => {
        if (cat.name !== categoryId) return cat;

        const updatedActivities = cat.activities.map(act => {
          if (act.id !== activityId) return act;
          
          const newActivity = { ...act, ...updates, lastUpdated: new Date().toISOString() };
          
          // Logic: If status is completed, set progress to 100
          if (updates.status === 'completed' && act.status !== 'completed') {
            newActivity.progress = 100;
            newActivity.completedAt = new Date().toISOString();
          }
          
          // Logic: If progress is 100, set status to completed
          if (updates.progress === 100 && act.progress !== 100) {
            newActivity.status = 'completed';
            newActivity.completedAt = new Date().toISOString();
          }

          // Logic: If progress < 100 and status was completed, revert
          if (updates.progress !== undefined && updates.progress < 100 && act.status === 'completed') {
            newActivity.status = 'pending';
            newActivity.completedAt = undefined; // Clear date
          }

          // Logic: If status changed FROM completed TO pending/stopped, clear date
          if (updates.status && updates.status !== 'completed' && act.status === 'completed') {
             newActivity.completedAt = undefined;
          }

          return newActivity;
        });

        const totalProgress = updatedActivities.reduce((sum, a) => sum + a.progress, 0);
        const avgProgress = updatedActivities.length > 0 ? Math.round(totalProgress / updatedActivities.length) : 0;

        return {
          ...cat,
          activities: updatedActivities,
          totalProgress: avgProgress
        };
      });

      return { ...proj, data: updatedCategories };
    }));
  };

  const handleAddActivity = () => {
    if (!newActivityData.category || !newActivityData.name || !currentProjectId) return;

    setProjects(prev => prev.map(proj => {
      if (proj.id !== currentProjectId) return proj;

      const updatedCategories = proj.data.map(cat => {
        if (cat.name !== newActivityData.category) return cat;

        // Find max ID across the project
        let maxId = 0;
        proj.data.forEach(c => c.activities.forEach(a => { if (a.id > maxId) maxId = a.id; }));
        
        const newActivity: Activity = {
          id: maxId + 1,
          category: cat.name,
          name: newActivityData.name,
          notes: '',
          status: 'pending',
          progress: 0
        };

        const updatedActivities = [...cat.activities, newActivity];
        const totalProgress = updatedActivities.reduce((sum, a) => sum + a.progress, 0);
        const avgProgress = Math.round(totalProgress / updatedActivities.length);

        return {
          ...cat,
          activities: updatedActivities,
          totalProgress: avgProgress
        };
      });

      return { ...proj, data: updatedCategories };
    }));

    setNewActivityOpen(false);
    setNewActivityData({ category: '', name: '' });
  };

  const handleDeleteActivity = (categoryName: string, activityId: number) => {
    if (!confirm("¿Estás seguro de eliminar esta actividad?") || !currentProjectId) return;

    setProjects(prev => prev.map(proj => {
      if (proj.id !== currentProjectId) return proj;

      const updatedCategories = proj.data.map(cat => {
        if (cat.name !== categoryName) return cat;

        const updatedActivities = cat.activities.filter(a => a.id !== activityId);
        const totalProgress = updatedActivities.reduce((sum, a) => sum + a.progress, 0);
        const avgProgress = updatedActivities.length > 0 ? Math.round(totalProgress / updatedActivities.length) : 0;

        return {
          ...cat,
          activities: updatedActivities,
          totalProgress: avgProgress
        };
      });

      return { ...proj, data: updatedCategories };
    }));
  };

  const handleAddIssue = () => {
    if (!newIssueData.description || !newIssueData.solution || !currentProjectId) return;
    
    setProjects(prev => prev.map(proj => {
      if (proj.id !== currentProjectId) return proj;
      
      const newIssue: Issue = {
        id: crypto.randomUUID(),
        description: newIssueData.description || '',
        solution: newIssueData.solution || '',
        severity: (newIssueData.severity || 50) as any,
        date: new Date().toISOString(),
        category: newIssueData.category
      };
      
      return { ...proj, issues: [...proj.issues, newIssue] };
    }));
    
    setNewIssueOpen(false);
    setNewIssueData({ severity: 50 });
  };

  const handleDeleteProject = () => {
    if (!currentProjectId || !confirm("¿Estás seguro de eliminar este proyecto? Esta acción no se puede deshacer.")) return;

    setProjects(prev => {
      const remaining = prev.filter(p => p.id !== currentProjectId);
      if (remaining.length > 0) {
        setCurrentProjectId(remaining[0].id);
      } else {
        setCurrentProjectId(null);
      }
      return remaining;
    });
  };

  const downloadSummary = async () => {
    if (weeklySummaryRef.current) {
      try {
        const dataUrl = await htmlToImage.toPng(weeklySummaryRef.current, { backgroundColor: '#ffffff' });
        const link = document.createElement('a');
        link.download = `resumen-semanal-${format(new Date(), 'yyyy-MM-dd')}.png`;
        link.href = dataUrl;
        link.click();
      } catch (error) {
        console.error('Error downloading summary', error);
      }
    }
  };

  const filteredCategories = useMemo(() => {
    if (!currentProject) return [];
    return currentProject.data.map(cat => {
      const filteredActivities = cat.activities.filter(act => {
        const matchesSearch = act.name.toLowerCase().includes(searchQuery.toLowerCase());
        const matchesFilter = statusFilter === 'all' || act.status === statusFilter;
        return matchesSearch && matchesFilter;
      });
      
      return {
        ...cat,
        activities: filteredActivities
      };
    }).filter(cat => cat.activities.length > 0);
  }, [currentProject, searchQuery, statusFilter]);

  const overallProgress = useMemo(() => {
    if (!currentProject || currentProject.data.length === 0) return 0;
    const total = currentProject.data.reduce((sum, cat) => sum + cat.totalProgress, 0);
    return Math.round(total / currentProject.data.length);
  }, [currentProject]);

  const weeklySummary = useMemo(() => {
    const now = new Date();
    const start = startOfWeek(now, { weekStartsOn: 1 }); // Monday
    const end = endOfWeek(now, { weekStartsOn: 1 });

    const completedThisWeek: Activity[] = [];
    const inProgress: Activity[] = [];

    if (currentProject) {
      currentProject.data.forEach(cat => {
        cat.activities.forEach(act => {
          if (act.status === 'completed' && act.completedAt) {
            const completedDate = new Date(act.completedAt);
            if (isWithinInterval(completedDate, { start, end })) {
              completedThisWeek.push(act);
            }
          } else if (act.progress > 0 && act.progress < 100) {
            inProgress.push(act);
          }
        });
      });
    }

    return { completedThisWeek, inProgress, start, end };
  }, [currentProject]);

  const chartData = useMemo(() => {
    if (!currentProject) return [];
    return currentProject.data.map(cat => ({
      name: cat.name, // Full name requested
      progress: cat.totalProgress,
      completed: cat.activities.filter(a => a.status === 'completed').length,
      total: cat.activities.length
    }));
  }, [currentProject]);

  const issuesData = useMemo(() => {
      if (!currentProject) return [];
      const severityCounts = {
          25: 0, 50: 0, 75: 0, 100: 0
      };
      currentProject.issues.forEach(i => {
          if (severityCounts[i.severity] !== undefined) severityCounts[i.severity]++;
      });
      return [
          { name: 'Leve (25)', value: severityCounts[25], fill: '#4ade80' },
          { name: 'Moderado (50)', value: severityCounts[50], fill: '#facc15' },
          { name: 'Grave (75)', value: severityCounts[75], fill: '#f97316' },
          { name: 'Crítico (100)', value: severityCounts[100], fill: '#ef4444' },
      ];
  }, [currentProject]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background text-foreground">
        <div className="flex flex-col items-center gap-4">
          <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin" />
          <p className="text-muted-foreground">Cargando datos de obra...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background text-foreground font-sans p-4 md:p-8 max-w-[1600px] mx-auto space-y-8">
      <div className="flex justify-end mb-2">
        <p className="text-xs text-muted-foreground">Realizado por: Daniela Irias</p>
      </div>
      
      {/* Header */}
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-6 border-b border-border pb-6">
        <div className="flex flex-col gap-2">
          <h1 className="text-3xl font-bold tracking-tight text-primary">Control de Obras</h1>
          <div className="flex items-center gap-2">
             <Select value={currentProjectId || ''} onValueChange={setCurrentProjectId}>
                <SelectTrigger className="w-[250px] h-9 border-primary/20 bg-primary/5">
                    <FolderOpen className="w-4 h-4 mr-2 text-primary" />
                    <SelectValue placeholder="Seleccionar Proyecto" />
                </SelectTrigger>
                <SelectContent>
                    {projects.map(p => (
                        <SelectItem key={p.id} value={p.id}>{p.name} ({p.code})</SelectItem>
                    ))}
                </SelectContent>
             </Select>
             
             <DropdownMenu>
                <DropdownMenuTrigger asChild>
                    <Button variant="outline" size="icon" className="h-9 w-9">
                        <MoreHorizontal className="w-4 h-4" />
                    </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                    <DropdownMenuItem onClick={handleDeleteProject} className="text-red-600 focus:text-red-600">
                        <Trash2 className="mr-2 h-4 w-4" />
                        Eliminar Proyecto
                    </DropdownMenuItem>
                </DropdownMenuContent>
             </DropdownMenu>
             
             <Dialog open={newProjectOpen} onOpenChange={setNewProjectOpen}>
                <DialogTrigger asChild>
                    <Button variant="outline" size="icon" className="h-9 w-9">
                        <FolderPlus className="w-4 h-4" />
                    </Button>
                </DialogTrigger>
                <DialogContent>
                    <DialogHeader>
                        <DialogTitle>Nuevo Proyecto</DialogTitle>
                        <DialogDescription>Crear un nuevo espacio de trabajo para otra obra.</DialogDescription>
                    </DialogHeader>
                    <div className="grid gap-4 py-4">
                        <div className="grid gap-2">
                            <Label>Nombre del Proyecto</Label>
                            <Input value={newProjectData.name} onChange={e => setNewProjectData(p => ({...p, name: e.target.value}))} placeholder="Ej: Torre Central" />
                        </div>
                        <div className="grid gap-2">
                            <Label>Código</Label>
                            <Input value={newProjectData.code} onChange={e => setNewProjectData(p => ({...p, code: e.target.value}))} placeholder="Ej: TOR-001" />
                        </div>
                    </div>
                    <DialogFooter>
                        <Button onClick={createProject} disabled={!newProjectData.name || !newProjectData.code}>Crear Proyecto</Button>
                    </DialogFooter>
                </DialogContent>
             </Dialog>
          </div>
        </div>
        
        <div className="flex flex-col md:flex-row items-end md:items-center gap-4">
             <Dialog open={newActivityOpen} onOpenChange={setNewActivityOpen}>
                <DialogTrigger asChild>
                    <Button className="gap-2">
                        <Plus className="w-4 h-4" /> Nueva Actividad
                    </Button>
                </DialogTrigger>
                <DialogContent>
                    <DialogHeader>
                        <DialogTitle>Agregar Nueva Actividad</DialogTitle>
                        <DialogDescription>
                            Crear una nueva tarea en el cronograma de obra.
                        </DialogDescription>
                    </DialogHeader>
                    <div className="grid gap-4 py-4">
                        <div className="grid grid-cols-4 items-center gap-4">
                            <Label htmlFor="category" className="text-right">
                                Categoría
                            </Label>
                            <Select 
                                value={newActivityData.category} 
                                onValueChange={(val) => setNewActivityData(prev => ({...prev, category: val}))}
                            >
                                <SelectTrigger className="col-span-3">
                                    <SelectValue placeholder="Seleccionar categoría" />
                                </SelectTrigger>
                                <SelectContent>
                                    {currentProject?.data.map(c => (
                                        <SelectItem key={c.name} value={c.name}>{c.name}</SelectItem>
                                    ))}
                                </SelectContent>
                            </Select>
                        </div>
                        <div className="grid grid-cols-4 items-center gap-4">
                            <Label htmlFor="name" className="text-right">
                                Nombre
                            </Label>
                            <Input 
                                id="name" 
                                value={newActivityData.name}
                                onChange={(e) => setNewActivityData(prev => ({...prev, name: e.target.value}))}
                                className="col-span-3" 
                                placeholder="Ej: Colocación de pisos"
                            />
                        </div>
                    </div>
                    <DialogFooter>
                        <Button variant="outline" onClick={() => setNewActivityOpen(false)}>Cancelar</Button>
                        <Button onClick={handleAddActivity} disabled={!newActivityData.category || !newActivityData.name}>Guardar</Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>

            <Card className="w-full md:w-auto min-w-[250px]">
            <CardContent className="p-4 flex items-center justify-between gap-4">
                <div>
                    <p className="text-sm font-medium text-muted-foreground">Progreso General</p>
                    <p className="text-2xl font-bold">{overallProgress}%</p>
                </div>
                <Progress value={overallProgress} className="h-2 w-20" />
            </CardContent>
            </Card>
        </div>
      </header>

      <Tabs defaultValue="activities" className="w-full">
        <div className="flex items-center justify-between mb-6 flex-wrap gap-4">
          <TabsList>
            <TabsTrigger value="activities" className="gap-2">
              <List className="w-4 h-4" /> Actividades
            </TabsTrigger>
            <TabsTrigger value="dashboard" className="gap-2">
              <BarChart3 className="w-4 h-4" /> Tablero de Control
            </TabsTrigger>
            <TabsTrigger value="pending" className="gap-2">
              <Clock className="w-4 h-4" /> Pendientes
            </TabsTrigger>
            <TabsTrigger value="issues" className="gap-2">
              <AlertTriangle className="w-4 h-4" /> Contratiempos
            </TabsTrigger>
          </TabsList>
        </div>

        {/* Activities Tab */}
        <TabsContent value="activities" className="space-y-6 animate-in fade-in-50 duration-500">
          <div className="flex flex-col md:flex-row gap-4 items-center justify-between bg-card p-4 rounded-lg border border-border shadow-sm">
            <div className="relative w-full md:w-96">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input 
                placeholder="Buscar actividad..." 
                className="pl-9"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            <div className="flex items-center gap-2 w-full md:w-auto">
              <Filter className="w-4 h-4 text-muted-foreground" />
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="Filtrar por estado" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos los estados</SelectItem>
                  <SelectItem value="pending">Pendiente</SelectItem>
                  <SelectItem value="completed">Completa</SelectItem>
                  <SelectItem value="stopped">Detenida</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-6">
            {filteredCategories.map((category) => (
              <div key={category.name} className="border border-border rounded-lg overflow-hidden bg-card shadow-sm">
                <div 
                  className="flex items-center justify-between p-4 bg-muted/30 hover:bg-muted/50 cursor-pointer transition-colors"
                  onClick={() => toggleCategory(category.name)}
                >
                  <div className="flex items-center gap-3">
                    <Button variant="ghost" size="icon" className="h-6 w-6 p-0 hover:bg-transparent">
                      {expandedCategories[category.name] ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
                    </Button>
                    <h3 className="font-semibold text-lg">{category.name}</h3>
                    <Badge variant="outline" className="ml-2">{category.activities.length} items</Badge>
                  </div>
                  <div className="flex items-center gap-4 min-w-[200px]">
                    <div className="flex flex-col items-end w-full">
                      <span className="text-xs text-muted-foreground mb-1">{category.totalProgress}% Completado</span>
                      <Progress value={category.totalProgress} className="h-2 w-32" />
                    </div>
                  </div>
                </div>

                {expandedCategories[category.name] && (
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead className="w-[50px]">ID</TableHead>
                          <TableHead className="min-w-[300px]">Actividad</TableHead>
                          <TableHead className="w-[150px]">Estado</TableHead>
                          <TableHead className="w-[180px]">Progreso</TableHead>
                          <TableHead className="w-[180px]">Fecha Completado</TableHead>
                          <TableHead className="min-w-[200px]">Notas</TableHead>
                          <TableHead className="w-[50px]"></TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {category.activities.map((activity) => (
                          <TableRow key={activity.id} className={activity.status === 'completed' ? 'bg-green-50/50 dark:bg-green-950/10' : ''}>
                            <TableCell className="font-mono text-muted-foreground">{activity.id}</TableCell>
                            <TableCell className="font-medium">{activity.name}</TableCell>
                            <TableCell>
                              <Select 
                                value={activity.status} 
                                onValueChange={(val: any) => updateActivity(category.name, activity.id, { status: val })}
                              >
                                <SelectTrigger className={`h-8 w-[130px] ${
                                  activity.status === 'completed' ? 'bg-green-100 text-green-700 border-green-200 dark:bg-green-900/30 dark:text-green-400 dark:border-green-900' : 
                                  activity.status === 'stopped' ? 'bg-red-100 text-red-700 border-red-200 dark:bg-red-900/30 dark:text-red-400 dark:border-red-900' : 
                                  ''
                                }`}>
                                  <SelectValue />
                                </SelectTrigger>
                                <SelectContent>
                                  <SelectItem value="pending">Pendiente</SelectItem>
                                  <SelectItem value="completed">Completa</SelectItem>
                                  <SelectItem value="stopped">Detenida</SelectItem>
                                </SelectContent>
                              </Select>
                            </TableCell>
                            <TableCell>
                              <div className="flex items-center gap-2">
                                <Select 
                                  value={activity.progress.toString()} 
                                  onValueChange={(val) => updateActivity(category.name, activity.id, { progress: parseInt(val) as any })}
                                >
                                  <SelectTrigger className="h-8 w-[100px]">
                                    <SelectValue />
                                  </SelectTrigger>
                                  <SelectContent>
                                    <SelectItem value="0">0%</SelectItem>
                                    <SelectItem value="25">25%</SelectItem>
                                    <SelectItem value="50">50%</SelectItem>
                                    <SelectItem value="75">75%</SelectItem>
                                    <SelectItem value="100">100%</SelectItem>
                                  </SelectContent>
                                </Select>
                                <div className="w-16 hidden md:block">
                                  <Progress value={activity.progress} className="h-1.5" />
                                </div>
                              </div>
                            </TableCell>
                            <TableCell className="text-muted-foreground text-sm">
                              {activity.completedAt ? (
                                <span>{format(new Date(activity.completedAt), 'dd/MM/yyyy')}</span>
                              ) : '-'}
                            </TableCell>
                            <TableCell>
                              <Input 
                                className="h-8 text-sm" 
                                placeholder="Agregar nota..." 
                                value={activity.notes}
                                onChange={(e) => updateActivity(category.name, activity.id, { notes: e.target.value })}
                              />
                            </TableCell>
                            <TableCell>
                                <DropdownMenu>
                                    <DropdownMenuTrigger asChild>
                                        <Button variant="ghost" className="h-8 w-8 p-0">
                                            <span className="sr-only">Abrir menú</span>
                                            <MoreHorizontal className="h-4 w-4" />
                                        </Button>
                                    </DropdownMenuTrigger>
                                    <DropdownMenuContent align="end">
                                        <DropdownMenuItem 
                                            onClick={() => updateActivity(category.name, activity.id, { urgent: !activity.urgent })}
                                        >
                                            {activity.urgent ? (
                                                <>
                                                    <ZapOff className="mr-2 h-4 w-4 text-yellow-600" />
                                                    Remover Urgencia
                                                </>
                                            ) : (
                                                <>
                                                    <Zap className="mr-2 h-4 w-4 text-yellow-600" />
                                                    Marcar como Urgente
                                                </>
                                            )}
                                        </DropdownMenuItem>
                                        <DropdownMenuSeparator />
                                        <DropdownMenuItem 
                                            className="text-red-600 focus:text-red-600"
                                            onClick={() => handleDeleteActivity(category.name, activity.id)}
                                        >
                                            <Trash2 className="mr-2 h-4 w-4" />
                                            Eliminar
                                        </DropdownMenuItem>
                                    </DropdownMenuContent>
                                </DropdownMenu>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                )}
              </div>
            ))}
          </div>
        </TabsContent>

        {/* Dashboard Tab */}
        <TabsContent value="dashboard" className="space-y-6 animate-in fade-in-50 duration-500">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <Card className="col-span-1 md:col-span-2 lg:col-span-2">
              <CardHeader>
                <CardTitle>Progreso por Categoría</CardTitle>
                <CardDescription>Avance porcentual de cada fase de la obra</CardDescription>
              </CardHeader>
              <CardContent className="h-[500px]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={chartData} layout="vertical" margin={{ left: 10, right: 40 }}>
                    <CartesianGrid strokeDasharray="3 3" horizontal={false} />
                    <XAxis type="number" domain={[0, 100]} unit="%" />
                    <YAxis type="category" dataKey="name" width={220} tick={{fontSize: 11}} interval={0} />
                    <Tooltip 
                      formatter={(value) => [`${value}%`, 'Progreso']}
                      contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 12px rgba(0,0,0,0.1)' }}
                      cursor={{fill: 'transparent'}}
                    />
                    <Bar dataKey="progress" radius={[0, 4, 4, 0]}>
                       {chartData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={`hsl(var(--chart-${(index % 5) + 1}))`} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card ref={weeklySummaryRef} className="bg-white">
              <CardHeader className="flex flex-row items-center justify-between">
                <div>
                    <CardTitle>Resumen Semanal</CardTitle>
                    <CardDescription>
                        Semana del {format(weeklySummary.start, 'dd/MM')} al {format(weeklySummary.end, 'dd/MM')}
                    </CardDescription>
                </div>
                <Button variant="ghost" size="icon" onClick={downloadSummary}>
                    <Download className="w-4 h-4" />
                </Button>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-[450px] pr-4">
                  <div className="space-y-6">
                    <div>
                      <h4 className="text-sm font-semibold text-green-600 mb-3 flex items-center gap-2">
                        <CheckCircle2 className="w-4 h-4" /> Completadas ({weeklySummary.completedThisWeek.length})
                      </h4>
                      {weeklySummary.completedThisWeek.length === 0 ? (
                        <p className="text-sm text-muted-foreground italic">No hay actividades completadas esta semana.</p>
                      ) : (
                        <ul className="space-y-3">
                          {weeklySummary.completedThisWeek.map(act => (
                            <li key={act.id} className="text-sm border-l-2 border-green-200 pl-3 py-1">
                              <p className="font-medium">{act.name}</p>
                              <p className="text-xs text-muted-foreground">{act.category}</p>
                            </li>
                          ))}
                        </ul>
                      )}
                    </div>

                    <div>
                      <h4 className="text-sm font-semibold text-blue-600 mb-3 flex items-center gap-2">
                        <Clock className="w-4 h-4" /> En Progreso ({weeklySummary.inProgress.length})
                      </h4>
                      <ul className="space-y-3">
                        {weeklySummary.inProgress.map(act => (
                          <li key={act.id} className="space-y-1 border-l-2 border-blue-200 pl-3 py-1">
                            <div className="flex justify-between text-sm">
                              <span className="font-medium">{act.name}</span>
                              <span className="text-blue-600 font-bold">{act.progress}%</span>
                            </div>
                            <p className="text-xs text-muted-foreground">{act.category}</p>
                            <Progress value={act.progress} className="h-1.5 bg-blue-100" />
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Pending Tab */}
        <TabsContent value="pending" className="space-y-6 animate-in fade-in-50 duration-500">
          <Card>
            <CardHeader>
              <CardTitle>Actividades Pendientes</CardTitle>
              <CardDescription>Listado de tareas por iniciar o en proceso - Prioridades al inicio</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-8">
                {filteredCategories.map(cat => {
                  const pendingActs = cat.activities.filter(a => a.status !== 'completed');
                  if (pendingActs.length === 0) return null;
                  
                  // Sort to show urgent items first
                  const sortedActs = [...pendingActs].sort((a, b) => {
                    if (a.urgent && !b.urgent) return -1;
                    if (!a.urgent && b.urgent) return 1;
                    return 0;
                  });
                  
                  return (
                    <div key={cat.name} className="space-y-4">
                      <h3 className="font-semibold text-lg flex items-center gap-2 border-b pb-2">
                        {cat.name} 
                        <Badge variant="secondary">{pendingActs.length}</Badge>
                      </h3>
                      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                        {sortedActs.map(act => (
                          <div key={act.id} className={`p-4 rounded-lg border hover:shadow-md transition-shadow relative overflow-hidden ${
                            act.urgent ? 'border-yellow-400 bg-yellow-50 dark:bg-yellow-950/20' : 'border-border bg-card'
                          }`}>
                            <div className={`absolute left-0 top-0 bottom-0 w-1 ${
                              act.urgent ? 'bg-yellow-500' : 
                              act.status === 'stopped' ? 'bg-red-500' : 'bg-blue-500'
                            }`} />
                            <div className="flex justify-between items-start mb-2 pl-2">
                              <div className="flex items-center gap-2">
                                <span className="text-xs font-mono text-muted-foreground">#{act.id}</span>
                                {act.urgent && <Zap className="w-4 h-4 text-yellow-600" />}
                              </div>
                              <Badge variant={act.status === 'stopped' ? 'destructive' : act.urgent ? 'default' : 'secondary'} className={act.urgent ? 'bg-yellow-500' : ''}>
                                {act.status === 'stopped' ? 'Detenida' : act.progress > 0 ? `${act.progress}%` : 'Pendiente'}
                              </Badge>
                            </div>
                            <h4 className="font-medium text-sm mb-4 pl-2 min-h-[40px]">{act.name}</h4>
                            <div className="pl-2">
                              <Select 
                                value={act.progress.toString()} 
                                onValueChange={(val) => updateActivity(cat.name, act.id, { progress: parseInt(val) as any })}
                              >
                                <SelectTrigger className="h-8 w-full text-xs">
                                  <SelectValue placeholder="Actualizar progreso" />
                                </SelectTrigger>
                                <SelectContent>
                                  <SelectItem value="0">0% - Sin iniciar</SelectItem>
                                  <SelectItem value="25">25% - Iniciado</SelectItem>
                                  <SelectItem value="50">50% - A la mitad</SelectItem>
                                  <SelectItem value="75">75% - Avanzado</SelectItem>
                                  <SelectItem value="100">100% - Completar</SelectItem>
                                </SelectContent>
                              </Select>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Issues Tab */}
        <TabsContent value="issues" className="space-y-6 animate-in fade-in-50 duration-500">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <Card className="md:col-span-2">
                    <CardHeader className="flex flex-row items-center justify-between">
                        <div>
                            <CardTitle>Registro de Contratiempos</CardTitle>
                            <CardDescription>Historial de problemas y soluciones</CardDescription>
                        </div>
                        <Dialog open={newIssueOpen} onOpenChange={setNewIssueOpen}>
                            <DialogTrigger asChild>
                                <Button variant="destructive" className="gap-2">
                                    <AlertOctagon className="w-4 h-4" /> Reportar Problema
                                </Button>
                            </DialogTrigger>
                            <DialogContent>
                                <DialogHeader>
                                    <DialogTitle>Reportar Contratiempo</DialogTitle>
                                    <DialogDescription>Describe el problema y la solución aplicada.</DialogDescription>
                                </DialogHeader>
                                <div className="grid gap-4 py-4">
                                    <div className="grid gap-2">
                                        <Label>Descripción del Problema</Label>
                                        <Input value={newIssueData.description || ''} onChange={e => setNewIssueData(d => ({...d, description: e.target.value}))} placeholder="Qué sucedió..." />
                                    </div>
                                    <div className="grid gap-2">
                                        <Label>Solución / Acción Tomada</Label>
                                        <Input value={newIssueData.solution || ''} onChange={e => setNewIssueData(d => ({...d, solution: e.target.value}))} placeholder="Cómo se resolvió..." />
                                    </div>
                                    <div className="grid gap-2">
                                        <Label>Gravedad / Impacto (%)</Label>
                                        <Select value={newIssueData.severity?.toString()} onValueChange={(val) => setNewIssueData(d => ({...d, severity: parseInt(val) as any}))}>
                                            <SelectTrigger>
                                                <SelectValue />
                                            </SelectTrigger>
                                            <SelectContent>
                                                <SelectItem value="25">25% - Leve</SelectItem>
                                                <SelectItem value="50">50% - Moderado</SelectItem>
                                                <SelectItem value="75">75% - Grave</SelectItem>
                                                <SelectItem value="100">100% - Crítico</SelectItem>
                                            </SelectContent>
                                        </Select>
                                    </div>
                                    <div className="grid gap-2">
                                        <Label>Categoría Relacionada (Opcional)</Label>
                                        <Select value={newIssueData.category || ''} onValueChange={(val) => setNewIssueData(d => ({...d, category: val}))}>
                                            <SelectTrigger>
                                                <SelectValue placeholder="Seleccionar categoría..." />
                                            </SelectTrigger>
                                            <SelectContent>
                                                {currentProject?.data.map(c => (
                                                    <SelectItem key={c.name} value={c.name}>{c.name}</SelectItem>
                                                ))}
                                            </SelectContent>
                                        </Select>
                                    </div>
                                </div>
                                <DialogFooter>
                                    <Button onClick={handleAddIssue} disabled={!newIssueData.description || !newIssueData.solution}>Registrar</Button>
                                </DialogFooter>
                            </DialogContent>
                        </Dialog>
                    </CardHeader>
                    <CardContent>
                        <Table>
                            <TableHeader>
                                <TableRow>
                                    <TableHead>Fecha</TableHead>
                                    <TableHead>Problema</TableHead>
                                    <TableHead>Solución</TableHead>
                                    <TableHead>Impacto</TableHead>
                                    <TableHead>Categoría</TableHead>
                                </TableRow>
                            </TableHeader>
                            <TableBody>
                                {currentProject?.issues.length === 0 ? (
                                    <TableRow>
                                        <TableCell colSpan={5} className="text-center py-8 text-muted-foreground">
                                            No hay contratiempos registrados.
                                        </TableCell>
                                    </TableRow>
                                ) : (
                                    currentProject?.issues.map(issue => (
                                        <TableRow key={issue.id}>
                                            <TableCell className="whitespace-nowrap">{format(new Date(issue.date), 'dd/MM/yyyy')}</TableCell>
                                            <TableCell className="font-medium">{issue.description}</TableCell>
                                            <TableCell>{issue.solution}</TableCell>
                                            <TableCell>
                                                <Badge variant={issue.severity >= 75 ? "destructive" : "secondary"}>
                                                    {issue.severity}%
                                                </Badge>
                                            </TableCell>
                                            <TableCell className="text-sm text-muted-foreground">{issue.category || '-'}</TableCell>
                                        </TableRow>
                                    ))
                                )}
                            </TableBody>
                        </Table>
                    </CardContent>
                </Card>
                
                <Card>
                    <CardHeader>
                        <CardTitle>Análisis de Riesgos</CardTitle>
                        <CardDescription>Distribución por gravedad</CardDescription>
                    </CardHeader>
                    <CardContent className="h-[300px]">
                        <ResponsiveContainer width="100%" height="100%">
                            <PieChart>
                                <Pie
                                    data={issuesData}
                                    cx="50%"
                                    cy="50%"
                                    innerRadius={60}
                                    outerRadius={80}
                                    paddingAngle={5}
                                    dataKey="value"
                                >
                                    {issuesData.map((entry, index) => (
                                        <Cell key={`cell-${index}`} fill={entry.fill} />
                                    ))}
                                </Pie>
                                <Tooltip />
                            </PieChart>
                        </ResponsiveContainer>
                        <div className="grid grid-cols-2 gap-2 mt-4">
                            {issuesData.map((entry, index) => (
                                <div key={index} className="flex items-center gap-2 text-xs">
                                    <div className="w-3 h-3 rounded-full" style={{backgroundColor: entry.fill}} />
                                    <span>{entry.name}: {entry.value}</span>
                                </div>
                            ))}
                        </div>
                    </CardContent>
                </Card>
            </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
