# Control de Obras - Sistema de Gestión de Proyectos de Construcción

Una aplicación web interactiva para gestionar y hacer seguimiento a múltiples proyectos de construcción con 15 categorías de actividades, progreso en tiempo real, seguimiento de problemas y reportes semanales.

## 🚀 Características

- **Gestión de múltiples proyectos**: Crear, editar y eliminar proyectos de construcción
- **15 categorías de actividades**: Organización completa del flujo constructivo
- **Seguimiento de progreso**: Marcar actividades en 4 niveles (25%, 50%, 75%, 100%)
- **Estados de actividades**: Pendiente, Completada, Detenida
- **Sistema de prioridades**: Marcar actividades como urgentes
- **Seguimiento de problemas**: Registrar contratiempos con niveles de severidad
- **Análisis visual**: Gráficos de progreso por categoría
- **Resúmenes semanales**: Descargables como imágenes
- **Persistencia local**: Todos los datos se guardan en localStorage
- **Interfaz en español**: Completamente en español para usuarios hispanohablantes

## 📋 Requisitos

- Node.js 16+ 
- npm o yarn

## 🛠️ Instalación

1. Clona este repositorio:
```bash
git clone https://github.com/tu-usuario/control-de-obras.git
cd control-de-obras
```

2. Instala las dependencias:
```bash
npm install
```

## 📱 Desarrollo

Para ejecutar la aplicación en modo desarrollo:

```bash
npm run dev:client
```

La aplicación estará disponible en `http://localhost:5000`

## 🏗️ Estructura del Proyecto

```
├── src/
│   ├── components/          # Componentes React reutilizables
│   │   └── ui/             # Componentes de Radix UI
│   ├── pages/              # Páginas de la aplicación
│   ├── lib/                # Utilidades y funciones compartidas
│   ├── hooks/              # Custom React hooks
│   ├── App.tsx             # Componente principal
│   ├── main.tsx            # Punto de entrada
│   ├── types.ts            # Tipos TypeScript
│   └── index.css           # Estilos globales
├── public/                 # Archivos estáticos
│   ├── data.txt           # Datos de actividades por defecto
│   └── favicon.png        # Favicon
├── package.json           # Dependencias del proyecto
├── vite.config.ts         # Configuración de Vite
├── tsconfig.json          # Configuración de TypeScript
└── README.md              # Este archivo
```

## 🔧 Configuración

### Variables de entorno
Si necesitas configurar variables de entorno, crea un archivo `.env.local`:

```
VITE_API_URL=http://localhost:3000
```

## 📊 Principales secciones de la app

### 1. **Actividades** (Pestaña principal)
- Visualiza todas las categorías de construcción expandibles
- Actualiza estado y progreso de cada actividad
- Agrega notas a las actividades
- Marca actividades como urgentes desde el menú

### 2. **Dashboard**
- Gráfico de progreso por categoría
- Resumen semanal con actividades completadas e en progreso
- Descarga de resúmenes como imágenes

### 3. **Pendientes**
- Vista filtrada de actividades no completadas
- Prioridades destacadas al inicio
- Selector rápido de progreso

### 4. **Problemas**
- Registro de contratiempos y problemas
- Niveles de severidad (Leve, Moderado, Grave, Crítico)
- Análisis de riesgo visual
- Historial completo

## 💾 Persistencia de Datos

Todos los datos se guardan automáticamente en `localStorage` del navegador:
- Proyectos creados
- Estados de actividades
- Notas y comentarios
- Problemas registrados
- Marcas de urgencia

## 🎨 Tecnologías Utilizadas

- **React 19** - Librería UI
- **TypeScript** - Tipado estático
- **Vite** - Bundler rápido
- **Tailwind CSS** - Estilos
- **Radix UI** - Componentes accesibles
- **Lucide Icons** - Iconografía
- **Recharts** - Gráficos
- **React Hook Form** - Manejo de formularios
- **date-fns** - Utilidades de fechas
- **Wouter** - Routing ligero

## 🤝 Contribuir

Las contribuciones son bienvenidas. Por favor:

1. Fork el proyecto
2. Crea una rama para tu feature (`git checkout -b feature/AmazingFeature`)
3. Commit tus cambios (`git commit -m 'Add some AmazingFeature'`)
4. Push a la rama (`git push origin feature/AmazingFeature`)
5. Abre un Pull Request

## 📝 Licencia

Este proyecto está bajo la Licencia MIT - ver el archivo LICENSE para detalles.

## 👤 Autor

**Daniela Irias**

## 📞 Soporte

Para reportar bugs o solicitar features, abre un issue en el repositorio.

## 🙏 Créditos

- Interfaz construida con Radix UI y componentes accesibles
- Gráficos con Recharts
- Iconos de Lucide React
- Estilos con Tailwind CSS

---

**Última actualización:** Diciembre 2025

**Versión:** 1.0.0
